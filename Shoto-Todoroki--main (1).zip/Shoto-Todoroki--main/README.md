<h1 align="center">
  <b> SuzuneHorikita </b>
</h1>
<h1 align="center"><img src="https://images6.fanpop.com/image/photos/41400000/Horikita-Suzune-wantadog-41400381-633-900.jpg" /></h1>

[![GitHub forks](https://img.shields.io/github/forks/desinobita/SuzuneHorikita?&style=flat-square&logo=github)](https://github.com/desinobita/SuzuneHorikita/fork)
[![GitHub stars](https://img.shields.io/github/stars/desinobita/SuzuneHorikita?&style=flat-square&logo=github)](https://github.com/desinobita/SuzuneHorikita/stargazers)
![Repo Size](https://img.shields.io/github/repo-size/desinobita/SuzuneHorikita?&style=flat-square&logo=github)
![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green?&style=flat-square)
[![GitHub license](https://img.shields.io/github/license/desinobita/SuzuneHorikita?&style=flat-square&logo=github)](https://github.com/desinobita/SuzuneHorikita/main/LICENSE)
[![Python](https://img.shields.io/badge/Python-v3.10-blue)](https://www.python.org/)
![Branch](https://img.shields.io/badge/Branch-Main-orange)
![GitHub language count](https://img.shields.io/github/languages/count/desinobita/SuzuneHorikita?color=Pink&label=Language&style=flat-square)

------

**A python, [pyrogram](https://github.com/iamgojoof6eyes/pyrogram) and [telegram.ext](https://github.com/python-telegram-bot/python-telegram-bot) based group management bot for telegram.
If you like the bot make sure to give a ⭐ __star__ ⭐ to this respository and feel free to update and sending pull requests**

-----

## Group Management 
***The SuzuneHorikita is a powerful Group Management bot.***

**If you counter any problem or face any bugs for help join 🌟 [Suzune Support](https://t.me/Suzune_Support) 🌟 and join 🔥[Suzune's Updates](https://t.me/SuzuneSuperbot)🔥 for bot update.**

Can be found on Telegram as 💫[@Suzune_Superbot](https://t.me/Suzune_Superbot)💫

------

# DEPLOYMENT 🚀
## Deploy To Heroku
**Make Sure you have Heroku account**

If you don't have heroku account what are you waiting for click [here](https://id.heroku.com/login) to make one or just deploy on other platform gudie is given below

Just click on the button it will redirect you to Heroku website and deploy your bot there....enjoy 😉

[![DEPLOY](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Kanekiken099999/Shoto-Todoroki-.git)

-----
# Credit
* [Akash Tiwari](https://github.com/desinobita) `Owner`
* [Captain Ezio](https://github.com/iamgojoof6eyes) `Dev`
* [Aksr aashish](https://github.com/aksr-aashish) `Dev`
* [The RiZoeL](https://github.com/MrRizoel) `Dev`
* [Zr Gang](https://github.com/akashti5) `Dev`

